#import <Flutter/Flutter.h>

@interface VibrationPlugin : NSObject<FlutterPlugin>
@end
