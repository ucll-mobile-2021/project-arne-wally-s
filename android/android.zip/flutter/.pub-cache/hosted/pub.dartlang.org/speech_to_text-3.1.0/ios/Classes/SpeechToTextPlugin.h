#import <Flutter/Flutter.h>

@interface SpeechToTextPlugin : NSObject<FlutterPlugin>
@end
