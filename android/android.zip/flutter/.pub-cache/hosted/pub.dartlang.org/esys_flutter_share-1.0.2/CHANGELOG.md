## 1.0.2

* update path_provider to 1.1.0
* optional text share added to Share.file & Share.files methods
* suppression of warnings "unchecked" in java code

## 1.0.1

* Update readme

## 1.0.0

* Breaking change. Adds support for sharing single and multiple files.

## 0.0.9

* Breaking change. Migrate from the deprecated original Android Support Library to AndroidX. This shouldn't result in any functional changes, but it requires   any Android apps using this plugin to [also migrate](https://developer.android.com/jetpack/androidx/migrate) if they're using the original support library.

## 0.0.8

* update path_provider to v0.5.0

## 0.0.7

* update compileSdkVersion to 28 and com.android.support:support-v4 to 28.0.0

## 0.0.6

* fixes crashes on iPad

## 0.0.5

* Use FileProvider subclass to avoid collisions

## 0.0.4

* meta information added

## 0.0.3

* meta information added

## 0.0.2

* meta information added

## 0.0.1

* initial release