package com.abccooking.abc_cooking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
